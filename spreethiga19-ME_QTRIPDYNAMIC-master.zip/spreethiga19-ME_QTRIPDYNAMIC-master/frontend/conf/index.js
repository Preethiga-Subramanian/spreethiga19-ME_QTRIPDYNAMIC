
const config = { backendEndpoint: "http://43.204.91.120:8082" };

export default config;
